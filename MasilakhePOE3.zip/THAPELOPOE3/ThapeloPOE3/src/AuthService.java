package quickchat;

import javax.swing.JOptionPane;

public class AuthService {

    public User login() {
        String username = JOptionPane.showInputDialog(
            null,
            "Enter your username:",
            "Login",
            JOptionPane.QUESTION_MESSAGE
        );

        if (username == null || username.trim().isEmpty()) {
            return null;
        }

        String password = JOptionPane.showInputDialog(
            null,
            "Enter your password:",
            "Login",
            JOptionPane.QUESTION_MESSAGE
        );

        if (password == null || password.trim().isEmpty()) {
            return null;
        }

        // Simple hardcoded authentication for demonstration
        if (username.equals("admin") && password.equals("password123")) {
            User user = new User(username, password);
            user.login(password);
            return user;
        } else {
            JOptionPane.showMessageDialog(
                null,
                "Invalid username or password",
                "Login Failed",
                JOptionPane.ERROR_MESSAGE
            );
            return null;
        }
    }

    public User register() {
        String username = JOptionPane.showInputDialog("Choose a username:");
        String password = JOptionPane.showInputDialog("Choose a password:");

        if (username != null && password != null && !username.isEmpty() && !password.isEmpty()) {
            return new User(username, password);
        } else {
            JOptionPane.showMessageDialog(null, "Registration failed. Try again.");
            return null;
        }
    }
}
