package quickchat;

import java.util.ArrayList;
import java.util.List;

public class MessageStore {
    private List<Message> messages = new ArrayList<>();

    public void addMessage(Message message) {
        messages.add(message);
    }

    public List<Message> getMessagesBySender(String sender) {
        List<Message> result = new ArrayList<>();
        for (Message message : messages) {
            if (message.getSender().equals(sender)) {
                result.add(message);
            }
        }
        return result;
    }

    public int getTotalMessages() {
        return messages.size();
    }
}
