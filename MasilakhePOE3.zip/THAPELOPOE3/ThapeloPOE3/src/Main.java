package quickchat;

import javax.swing.JOptionPane;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat", "QuickChat", JOptionPane.INFORMATION_MESSAGE);

        AuthService authService = new AuthService();
        User user = null;

        // Authentication Loop
        while (user == null) {
            String[] options = {"Login", "Register", "Exit"};
            int choice = JOptionPane.showOptionDialog(
                    null, "Choose an option:", "Authentication",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 0) {
                user = authService.login();
                if (user == null) {
                    JOptionPane.showMessageDialog(null, "Login failed. Try again.");
                }
            } else if (choice == 1) {
                user = authService.register();
                if (user != null) {
                    JOptionPane.showMessageDialog(null, "Registration successful! You are now logged in.");
                }
            } else {
                return;
            }
        }

        boolean running = true;
        MessageStore messageStore = new MessageStore();

        while (running) {
            String choice = JOptionPane.showInputDialog(
                null,
                "Please choose an option:\n" +
                "1) Send Messages\n" +
                "2) Show recently sent messages\n" +
                "3) Quit",
                "QuickChat Menu",
                JOptionPane.PLAIN_MESSAGE
            );

            if (choice == null) {
                running = false;
                continue;
            }

            switch (choice.trim()) {
                case "1":
                    sendMessages(user, messageStore);
                    break;
                case "2":
                    List<Message> messages = messageStore.getMessagesBySender(user.getUsername());
                    if (messages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages found.");
                    } else {
                        StringBuilder sb = new StringBuilder("Your messages:\n");
                        for (Message msg : messages) {
                            sb.append("To: ").append(msg.getRecipient())
                              .append("\nContent: ").append(msg.getContent())
                              .append("\nID: ").append(msg.getMessageId())
                              .append("\nHash: ").append(msg.getMessageHash())
                              .append("\nSent: ").append(msg.isSent())
                              .append(" | Read: ").append(msg.isRead())
                              .append(" | Received: ").append(msg.isReceived())
                              .append("\n------------------------\n");
                        }
                        JOptionPane.showMessageDialog(null, sb.toString());
                    }
                    break;
                case "3":
                    running = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!", "QuickChat", JOptionPane.INFORMATION_MESSAGE);
    }

    private static void sendMessages(User user, MessageStore messageStore) {
        String numMessagesStr = JOptionPane.showInputDialog(
            null,
            "How many messages would you like to send?",
            "Message Count",
            JOptionPane.QUESTION_MESSAGE
        );

        if (numMessagesStr == null) return;
        int numMessages = 0;

        try {
            numMessages = Integer.parseInt(numMessagesStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            Message message = new Message();
            message.setSender(user.getUsername());

            String recipient = JOptionPane.showInputDialog(
                null,
                "Enter recipient's phone number (with international code, max 10 chars):",
                "Recipient Info",
                JOptionPane.QUESTION_MESSAGE
            );
            if (recipient == null) return;
            if (!message.checkRecipientCell(recipient)) {
                JOptionPane.showMessageDialog(
                    null,
                    "Invalid phone number. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
                i--;
                continue;
            }
            message.setRecipient(recipient);

            String content = JOptionPane.showInputDialog(
                null,
                "Enter your message (max 20 characters):",
                "Message Content",
                JOptionPane.QUESTION_MESSAGE
            );
            if (content == null) return;
            if (content.length() > 20) {
                JOptionPane.showMessageDialog(
                    null,
                    "Please enter a message of less than 20 characters.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
                i--;
                continue;
            }
            message.setContent(content);
            message.createMessageHash();

            JOptionPane.showMessageDialog(
                null,
                "Message Details:\n" +
                "ID: " + message.getMessageId() + "\n" +
                "Hash: " + message.getMessageHash() + "\n" +
                "Recipient: " + message.getRecipient() + "\n" +
                "Content: " + message.getContent(),
                "Message Info",
                JOptionPane.INFORMATION_MESSAGE
            );

            String[] options = {"Send Message", "Disregard Message", "Store Message"};
            int action = JOptionPane.showOptionDialog(
                null,
                "What would you like to do with this message?",
                "Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
            );

            if (action == -1) return;

            switch (action) {
                case 0:
                    message.setSent(true);
                    message.setReceived(true);
                    message.setRead(true);
                    messageStore.addMessage(message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Message disregarded.", "Info", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2:
                    messageStore.addMessage(message);
                    JOptionPane.showMessageDialog(null, "Message successfully stored.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    break;
            }
        }

        JOptionPane.showMessageDialog(
            null,
            "Total messages processed: " + messageStore.getTotalMessages(),
            "Summary",
            JOptionPane.INFORMATION_MESSAGE
        );
    }
}
