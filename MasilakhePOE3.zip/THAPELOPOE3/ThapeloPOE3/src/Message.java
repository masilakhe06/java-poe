
package quickchat;

import java.util.UUID;

public class Message {
    private String messageId;
    private String messageHash;
    private String sender;
    private String recipient;
    private String content;
    private boolean sent;
    private boolean received;
    private boolean read;

    public Message() {
        this.messageId = UUID.randomUUID().toString();
        this.sent = false;
        this.received = false;
        this.read = false;
    }

    public void createMessageHash() {
        this.messageHash = Integer.toHexString((sender + recipient + content + messageId).hashCode());
    }

    public boolean checkRecipientCell(String cell) {
        return cell != null && cell.matches("^\\+27\\d{9}$");
    }


    public String getMessageId() {
        return messageId;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isSent() {
        return sent;
    }

    public void setSent(boolean sent) {
        this.sent = sent;
    }

    public boolean isReceived() {
        return received;
    }

    public void setReceived(boolean received) {
        this.received = received;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }
}
