
import java.util.*;
import java.io.*;
import org.json.simple.*;
import org.json.simple.parser.*;

public class MessageApp {
    static List<Message> sentMessages = new ArrayList<>();
    static List<Message> disregardedMessages = new ArrayList<>();
    static List<Message> storedMessages = new ArrayList<>();
    static Map<String, String> messageHashes = new HashMap<>();
    static Map<String, Integer> messageIDs = new HashMap<>();

    static int messageCounter = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        loadStoredMessages();

        while (true) {
            System.out.println("\n1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. View Sent Messages");
            System.out.println("4. Display Longest Message");
            System.out.println("5. Search by Message ID");
            System.out.println("6. Search by Recipient");
            System.out.println("7. Delete by Hash");
            System.out.println("8. Display Report");
            System.out.println("9. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Sender: ");
                    String sender = scanner.nextLine();
                    System.out.print("Recipient: ");
                    String recipient = scanner.nextLine();
                    System.out.print("Message: ");
                    String content = scanner.nextLine();
                    Message message = new Message(sender, recipient, content);
                    sentMessages.add(message);
                    messageHashes.put(message.hash, content);
                    messageIDs.put(message.hash, messageCounter++);
                    break;
                case 2:
                    System.out.print("Enter message to disregard: ");
                    String disregard = scanner.nextLine();
                    disregardedMessages.add(new Message("N/A", "N/A", disregard));
                    break;
                case 3:
                    for (Message m : sentMessages) {
                        System.out.println("From: " + m.sender + " To: " + m.recipient);
                    }
                    break;
                case 4:
                    Message longest = null;
                    for (Message m : sentMessages) {
                        if (longest == null || m.content.length() > longest.content.length()) {
                            longest = m;
                        }
                    }
                    if (longest != null) {
                        System.out.println("Longest Message: " + longest.content);
                    }
                    break;
                case 5:
                    System.out.print("Enter message hash: ");
                    String searchHash = scanner.nextLine();
                    if (messageIDs.containsKey(searchHash)) {
                        int id = messageIDs.get(searchHash);
                        for (Message m : sentMessages) {
                            if (m.hash.equals(searchHash)) {
                                System.out.println("ID: " + id + ", Recipient: " + m.recipient + ", Message: " + m.content);
                                break;
                            }
                        }
                    } else {
                        System.out.println("Message not found.");
                    }
                    break;
                case 6:
                    System.out.print("Enter recipient name: ");
                    String searchRecipient = scanner.nextLine();
                    for (Message m : sentMessages) {
                        if (m.recipient.equalsIgnoreCase(searchRecipient)) {
                            System.out.println("From: " + m.sender + " Message: " + m.content);
                        }
                    }
                    break;
                case 7:
                    System.out.print("Enter hash to delete: ");
                    String deleteHash = scanner.nextLine();
                    sentMessages.removeIf(m -> m.hash.equals(deleteHash));
                    messageHashes.remove(deleteHash);
                    messageIDs.remove(deleteHash);
                    break;
                case 8:
                    System.out.println("===== Sent Messages Report =====");
                    for (Message m : sentMessages) {
                        System.out.println("From: " + m.sender + ", To: " + m.recipient + ", Message: " + m.content + ", Hash: " + m.hash);
                    }
                    System.out.println("Total Messages Sent: " + returnTotalMessages());
                    break;
                case 9:
                    System.exit(0);
                    break;
            }
        }
    }

    static void loadStoredMessages() {
        try {
            JSONParser parser = new JSONParser();
            FileReader reader = new FileReader("messages.json");
            JSONArray array = (JSONArray) parser.parse(reader);
            for (Object obj : array) {
                JSONObject json = (JSONObject) obj;
                String sender = (String) json.get("sender");
                String recipient = (String) json.get("recipient");
                String content = (String) json.get("content");
                storedMessages.add(new Message(sender, recipient, content));
            }
            reader.close();
        } catch (Exception e) {
            System.out.println("Could not load stored messages.");
        }
    }

    public static List<String> printMessages() {
        List<String> result = new ArrayList<>();
        for (Message m : sentMessages) {
            result.add(m.content);
        }
        return result;
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }
}
